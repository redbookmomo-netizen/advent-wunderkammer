# The Grand Advent Wunderkammer — 24 independent door images

24 days, each as an individual image, numbered **door-01** through **door-24**.

- `webp_for_website/`: 24 images, each **768 × 1024 pixels** (3:4), visually tight crops ideal for a door-opening reveal. These are 2D still images; animation needs to be added in the webpage.
- `png_full_frame/`: 24 images, each **768 × 1024 pixels** (3:4), preserving each original compartment frame without stretching. Days 01–08 have dark side margins because their original artwork was exceptionally tall and narrow.
- The solo high-resolution illustration is used for day 24 in both sets.
- Backgrounds are not transparent. The artwork is intended to be shown behind the opening door.

Example HTML (assumes you copied the webp folder into your project):

```html
<img src="webp_for_website/door-01.webp" alt="Day 1 miniature" style="width:100%;height:100%;object-fit:cover" />
```

All 24 are static crops of the original generated artworks; they are not rendered 3D assets, layers, or frame animations. See `manifest.json` for the source mapping.
